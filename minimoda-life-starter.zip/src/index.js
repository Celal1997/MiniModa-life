const json = (data, status = 200) => new Response(JSON.stringify(data), {
  status,
  headers: {
    "content-type": "application/json; charset=utf-8",
    "access-control-allow-origin": "*",
    "access-control-allow-methods": "GET,POST,PUT,PATCH,DELETE,OPTIONS",
    "access-control-allow-headers": "Content-Type, X-Admin-Token"
  }
});

const err = (message, status = 400) => json({ error: message }, status);

function isAdmin(request, env) {
  const expected = env.ADMIN_TOKEN;
  const provided = request.headers.get("X-Admin-Token");
  return Boolean(expected && provided && provided === expected);
}

function requireAdmin(request, env) {
  if (!isAdmin(request, env)) return err("Admin icazəsi tələb olunur.", 401);
  return null;
}

function cleanProduct(p) {
  return {
    name: String(p.name || "").trim().slice(0, 160),
    category: String(p.category || "Geyim").trim().slice(0, 80),
    description: String(p.description || "").trim().slice(0, 2000),
    price: Number(p.price),
    old_price: p.old_price === "" || p.old_price == null ? null : Number(p.old_price),
    stock: Math.max(0, Math.floor(Number(p.stock) || 0)),
    sizes: String(p.sizes || "").slice(0, 500),
    colors: String(p.colors || "").slice(0, 500),
    image: String(p.image || "").trim().slice(0, 1000),
    active: p.active === false || p.active === 0 ? 0 : 1
  };
}

async function readJson(request) {
  try { return await request.json(); } catch { return null; }
}

export default {
  async fetch(request, env) {
    if (request.method === "OPTIONS") return new Response(null, {
      headers: {
        "access-control-allow-origin": "*",
        "access-control-allow-methods": "GET,POST,PUT,PATCH,DELETE,OPTIONS",
        "access-control-allow-headers": "Content-Type, X-Admin-Token"
      }
    });

    const url = new URL(request.url);
    const path = url.pathname.replace(/\/+$/, "") || "/";

    try {
      if (path === "/api/health" && request.method === "GET") {
        return json({ ok: true, store: env.STORE_NAME || "MiniModa life" });
      }

      if (path === "/api/products" && request.method === "GET") {
        const { results } = await env.DB.prepare(
          "SELECT id,name,category,description,price,old_price,stock,sizes,colors,image FROM products WHERE active=1 ORDER BY created_at DESC, id DESC"
        ).all();
        return json({ products: results || [] });
      }

      if (path === "/api/orders" && request.method === "POST") {
        const body = await readJson(request);
        if (!body || !String(body.customer_name || "").trim() || !String(body.phone || "").trim()) {
          return err("Ad və telefon nömrəsi mütləqdir.");
        }
        if (!Array.isArray(body.items) || body.items.length < 1 || body.items.length > 50) {
          return err("Səbətdə 1–50 məhsul olmalıdır.");
        }
        const delivery = body.delivery_method === "pickup" ? "pickup" : "delivery";
        const items = [];
        let total = 0;
        for (const item of body.items) {
          const id = Number(item.id);
          const qty = Math.floor(Number(item.quantity));
          if (!Number.isInteger(id) || qty < 1 || qty > 20) return err("Məhsul sayı düzgün deyil.");
          const product = await env.DB.prepare(
            "SELECT id,name,price,stock,active FROM products WHERE id=?"
          ).bind(id).first();
          if (!product || !product.active) return err("Məhsul tapılmadı və ya satışda deyil.", 409);
          if (product.stock < qty) return err(`${product.name}: stokda kifayət qədər məhsul yoxdur.`, 409);
          const price = Number(product.price);
          total += price * qty;
          items.push({
            id, name: product.name, price, quantity: qty,
            size: String(item.size || "").slice(0, 40),
            color: String(item.color || "").slice(0, 60)
          });
        }
        const name = String(body.customer_name).trim().slice(0, 120);
        const phone = String(body.phone).trim().slice(0, 40);
        const address = String(body.address || "").trim().slice(0, 500);
        const note = String(body.note || "").trim().slice(0, 1000);
        if (delivery === "delivery" && !address) return err("Çatdırılma ünvanını daxil edin.");
        const result = await env.DB.prepare(
          "INSERT INTO orders (customer_name,phone,address,delivery_method,note,items_json,total) VALUES (?,?,?,?,?,?,?)"
        ).bind(name, phone, address, delivery, note, JSON.stringify(items), Number(total.toFixed(2))).run();

        // Stok MVP-də sifariş təsdiqlənənədək avtomatik azaldılmır.
        return json({
          ok: true, order_id: result.meta.last_row_id, total: Number(total.toFixed(2)),
          message: "Sifariş qəbul edildi. Mağaza sizinlə əlaqə saxlayacaq."
        }, 201);
      }

      if (path.startsWith("/api/admin/")) {
        const authError = requireAdmin(request, env);
        if (authError) return authError;
      }

      if (path === "/api/admin/products" && request.method === "GET") {
        const { results } = await env.DB.prepare("SELECT * FROM products ORDER BY id DESC").all();
        return json({ products: results || [] });
      }

      if (path === "/api/admin/products" && request.method === "POST") {
        const body = await readJson(request);
        if (!body) return err("Məlumat oxunmadı.");
        const p = cleanProduct(body);
        if (!p.name || !Number.isFinite(p.price) || p.price < 0) return err("Məhsul adı və düzgün qiymət tələb olunur.");
        const result = await env.DB.prepare(
          "INSERT INTO products (name,category,description,price,old_price,stock,sizes,colors,image,active) VALUES (?,?,?,?,?,?,?,?,?,?)"
        ).bind(p.name,p.category,p.description,p.price,p.old_price,p.stock,p.sizes,p.colors,p.image,p.active).run();
        return json({ ok: true, id: result.meta.last_row_id }, 201);
      }

      const productMatch = path.match(/^\/api\/admin\/products\/(\d+)$/);
      if (productMatch && request.method === "PUT") {
        const body = await readJson(request);
        if (!body) return err("Məlumat oxunmadı.");
        const p = cleanProduct(body);
        if (!p.name || !Number.isFinite(p.price) || p.price < 0) return err("Məhsul adı və düzgün qiymət tələb olunur.");
        const result = await env.DB.prepare(
          "UPDATE products SET name=?,category=?,description=?,price=?,old_price=?,stock=?,sizes=?,colors=?,image=?,active=? WHERE id=?"
        ).bind(p.name,p.category,p.description,p.price,p.old_price,p.stock,p.sizes,p.colors,p.image,p.active,Number(productMatch[1])).run();
        return json({ ok: true, changes: result.meta.changes });
      }
      if (productMatch && request.method === "DELETE") {
        await env.DB.prepare("DELETE FROM products WHERE id=?").bind(Number(productMatch[1])).run();
        return json({ ok: true });
      }

      if (path === "/api/admin/orders" && request.method === "GET") {
        const { results } = await env.DB.prepare("SELECT * FROM orders ORDER BY created_at DESC, id DESC LIMIT 500").all();
        return json({ orders: (results || []).map(o => ({ ...o, items: safeParse(o.items_json) })) });
      }

      const orderMatch = path.match(/^\/api\/admin\/orders\/(\d+)$/);
      if (orderMatch && request.method === "PATCH") {
        const body = await readJson(request);
        const allowed = ["Yeni","Təsdiqləndi","Hazırlanır","Yoldadır","Tamamlandı","Ləğv edildi"];
        if (!body || !allowed.includes(body.status)) return err("Status düzgün deyil.");
        const result = await env.DB.prepare("UPDATE orders SET status=? WHERE id=?")
          .bind(body.status, Number(orderMatch[1])).run();
        return json({ ok: true, changes: result.meta.changes });
      }

      return err("Tapılmadı.", 404);
    } catch (e) {
      return json({ error: "Server xətası. Cloudflare Worker loglarına baxın." }, 500);
    }
  }
};

function safeParse(value) {
  try { return JSON.parse(value || "[]"); } catch { return []; }
}
