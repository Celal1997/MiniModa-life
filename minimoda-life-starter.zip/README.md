# MiniModa life — başlanğıc onlayn mağaza

Bu layihə Cloudflare Workers + D1 + statik frontend üçün başlanğıc versiyadır. Müştəri məhsullara baxa, ölçü/rəng seçə, səbət yarada və sifariş göndərə bilər. Admin məhsulları və sifarişləri idarə edir. Sifarişdən sonra WhatsApp mesajı açmaq üçün düymə göstərilir.

## Vacib qeyd
Bu, işə salına bilən MVP başlanğıcıdır, amma real müştərilərə açmazdan əvvəl aşağıdakıları tamamlayın:
- `ADMIN_TOKEN` üçün uzun, təsadüfi gizli dəyər təyin edin.
- `WHATSAPP_NUMBER`-ı ölkə kodu ilə, yalnız rəqəmlər şəklində daxil edin (məsələn, Azərbaycan üçün `994...`).
- Məhsul şəkilləri üçün öz hüququnuz olan şəkillərdən istifadə edin.
- Sifarişlərin ləğvi, stokun sifariş zamanı azaldılması, spam/rate-limit, məxfilik mətni və ehtiyat nüsxə siyasətini real satışdan əvvəl yoxlayın.
- `ADMIN_TOKEN` müştəriyə göstərilməməlidir. Admin panelinə yalnız etibarlı cihazlardan daxil olun.
- Kart ödənişi bu ilkin versiyaya daxil deyil; başlanğıcda çatdırılmada ödəniş / mağazadan götürmə nəzərdə tutulub.

## Fayl strukturu
- `public/` — mağazanın frontend-i və PWA faylları
- `src/index.js` — Cloudflare Worker API
- `migrations/0001_init.sql` — D1 cədvəlləri
- `wrangler.toml` — Worker konfiqurasiyası

## Cloudflare-də quraşdırma

1. Cloudflare hesabında **Workers & Pages → D1 SQL Database** bölməsində `minimoda-db` adlı D1 bazası yaradın.
2. Bazanın ID-sini `wrangler.toml` faylındakı `database_id` yerinə yazın.
3. Terminalda Node.js və Wrangler quraşdırılmış kompüterdə layihə qovluğuna keçin:
   ```bash
   npm install -g wrangler
   wrangler login
   wrangler d1 execute minimoda-db --remote --file=migrations/0001_init.sql
   ```
4. Admin token və WhatsApp nömrəsini secret kimi əlavə edin:
   ```bash
   wrangler secret put ADMIN_TOKEN
   wrangler secret put WHATSAPP_NUMBER
   ```
   `ADMIN_TOKEN` üçün uzun, təsadüfi və başqa yerdə istifadə etmədiyiniz parol seçin. `WHATSAPP_NUMBER` məsələn `994501234567` formatında olmalıdır.
5. `wrangler.toml` daxilində `database_id`-ni düzgün yazın, sonra:
   ```bash
   wrangler deploy
   ```
6. Frontend-i dərc etmək üçün ən sadə yol: `public/` qovluğundakı faylları Cloudflare Pages layihəsinə yerləşdirin. Sonra `public/config.js` faylındakı `API_BASE` dəyərini Worker URL-i ilə dəyişin. Məsələn:
   ```js
   window.MINIMODA_CONFIG = {
     API_BASE: "https://SENIN-WORKER-ADIN.workers.dev",
     WHATSAPP_NUMBER: "994501234567"
   };
   ```
   `WHATSAPP_NUMBER` frontend config-də də olmalıdır ki, WhatsApp düyməsi işləsin. Bu nömrə gizli deyil.
7. Pages-də `public/` qovluğunu statik sayt kimi dərc edin. `index.html` kökdə olmalıdır.
8. Saytı HTTPS linki ilə açın. Android Chrome-da menyudan **Add to Home screen / Əsas ekrana əlavə et** seçin.

## Admin panelinə giriş
Saytın yuxarısındakı **Admin** düyməsini basın və `ADMIN_TOKEN` secret kimi saxladığınız dəyəri daxil edin. Token yalnız admin brauzerində saxlanır. İctimai cihazlarda istifadə etməyin; iş bitəndə çıxış edin.

## Məhsulları toplu yükləmək
Bu MVP-də admin panelindən məhsul əlavə etmək mümkündür. 500+ məhsul üçün növbəti addım CSV/Excel import funksiyası əlavə etməkdir. CSV sahələri üçün tövsiyə:
`name,category,price,stock,sizes,colors,image,description`
` sizes` və `colors` dəyərlərini vergüllə ayırın.

## API
- `GET /api/products` — aktiv məhsullar
- `POST /api/orders` — müştəri sifarişi
- `GET /api/admin/products` — admin məhsulları
- `POST /api/admin/products` — məhsul yarat
- `PUT /api/admin/products/:id` — məhsulu dəyiş
- `DELETE /api/admin/products/:id` — məhsulu sil
- `GET /api/admin/orders` — sifarişlər
- `PATCH /api/admin/orders/:id` — sifariş statusu dəyiş

Admin API sorğularında `X-Admin-Token: <ADMIN_TOKEN>` başlığı istifadə olunur.

## Pulsuz tariflər
Cloudflare-in pulsuz limitləri dəyişə bilər. D1/Workers limitlərinə nəzarət edin; şəkillər üçün R2 istifadəsi və trafik böyüdükcə xərclər yarana bilər. Öz domeni ayrıca ödəniş tələb edə bilər.
